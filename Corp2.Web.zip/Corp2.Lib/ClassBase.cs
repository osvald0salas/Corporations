﻿namespace Corp2.Lib
{
    public class ClassBase
    {
        public string ErrorDescription { get; set; }
    }
}
